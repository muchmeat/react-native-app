/**
 * 全局配置项组件
 * Created by ruixin on 16/7/14.
 */
import React, {Component} from 'react';

export default class Global extends Component {

    // static REQUEST_BASE_URL = 'http://192.168.0.125:8087/plat'; //测试地址
    static REQUEST_BASE_URL = 'http://172.28.1.208:8082/zybzzxt/'; //测试地址
    static DTTB_IMAGE_URL = 'http://172.28.1.208:8082/zybzzxt//medias/style/plat/image/dttb/'; //动态图标地址
    // static REQUEST_BASE_URL = 'http://192.168.0.125:8087/plat/'; //测试地址
}