import * as t from '../.'

declare function isSubsetOf(subset: t.Type<any>, superset: t.Type<any>): boolean;

export default isSubsetOf