import React, {Component} from 'react';
import {
    View,Alert
} from 'react-native';
import {connect} from 'react-redux';
import styles from '../../style/ThemeStyle';
import RxForm from '../../../base/components/RxForm';
import t from "tcomb-form-native";
import DefualtBtn from '../../../base/components/DefualtBtn';
import * as formAction from '../../actions/formAction';
import * as formUtil from '../../../base/tcom/formUtil';
import Loading from "../../../base/components/Loading";
import FetchUtil from "../../../../utils/FetchUtil";
import Global from "../../../../utils/Global";
import {NavigationActions} from "react-navigation";

class DynamicsForm extends Component {

    static navigationOptions = {
        title: '表单',
    };


    componentWillMount() {
        let _this = this;
        let {setResult} = _this.props;
        let formId = _this.props.navigation.getParam("formId", null);
        formAction.getFormSetting(formId, setResult);
    }

    _commit() {
        let _this = this;
        let RxForm = _this.refs.RxForm._commit();
        console.log(RxForm);
        if (RxForm.errors.length > 0) {
            return
        }
        let formData = RxForm.value;
        let params = {
            formId: _this.props.navigation.getParam("formId", null),
            rwId: _this.props.navigation.getParam("rwId", null),
            formData: formData
        };
        FetchUtil.postJsonStr(Global.REQUEST_BASE_URL + "/dynamicForm/saveDynamicForm", params, (result) => {
            Alert.alert("温馨提示","采集成功");
            _this.props.navigation.goBack();
        }, (error) => {
            alert(JSON.stringify(error));
        }, () => {
        });
    }

    componentDidMount() {

    }

    shouldComponentUpdate(nextProps, nextState) {
        return true;
    }

    render() {
        let _this = this;
        let {formStatus, formData} = _this.props;
        let form = {};
        if (formStatus === "1") {
            form = formUtil.getSetTTings(formData.fields, t);
        }
        return (
            <View style={styles.container}>
                {formData ?
                    <RxForm ref="RxForm" rows={form.rows} options={form.options} values={form.values}/>
                    : <Loading viewStyle={{height: 200}} imageStyle={{width: 42, height: 42}}/>
                }
                <DefualtBtn text={"提  交"} click={() => {
                    _this._commit()
                }}/>
            </View>
        )
    }

    componentWillUnmount() {

    }

}

export default connect(
    (state) => ({
            formStatus: state.formReducer.formGetStatus,
            formData: state.formReducer.formData
        }
    ), (dispatch) => ({
        setResult: (status, data) => dispatch(formAction.setResult(status, data))
    })
)(DynamicsForm)
