export const SETDYNAMICFORMLIST = 'setDynamicFormList';
export const CLEARDYNAMICFORMLIST = 'clearDynamicFormList';