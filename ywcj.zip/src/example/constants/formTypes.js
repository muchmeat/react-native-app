export const GET_FORM = 'GET_FORM';
export const GET_ON = '0';
export const GET_SECCUSE = '1';
export const GET_ERROR = '2';
export const GET_OUTOFTIME = '3';
