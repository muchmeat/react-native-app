export const LOGIN = 'LOGIN';
export const LOGIN_INIT = 'LOGIN_INIT';
export const LOGIN_TOP_FOCUSE = 'LOGIN_TOP_FOCUSE';
export const LOGIN_BOTTOM_FOCUSE = 'LOGIN_BOTTOM_FOCUSE';
