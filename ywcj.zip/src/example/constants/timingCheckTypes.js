export const SETHISTORYLIST = 'setHistoryList';
export const SETSEARCHNAME = 'setSearchName';
export const SHOWDATEPICKER = 'showDatePicker';
export const SETVALUETIME = 'setValueTime';
export const TIMINGCHECKSETPICS = 'timingCheckSetPics';
export const SETSAVERESULT = 'setSaveResult';
